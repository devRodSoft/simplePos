<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=smartpos_sex',
    'username' => 'smartpos_sex',
    'password' => 'sex2020',
    'charset' => 'utf8'

    /*'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=http://myrodsoft.com/;dbname=myrodsof_sex',
    'username' => 'myrodsof_sex',
    'password' => 'sex2020Rodsoft',
    'charset' => 'utf8'*/

    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60,
    //'schemaCache' => 'cache', 
];
