<?php
  var_dump($selectedProductos);
?>