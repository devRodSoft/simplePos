<?php

/* @var $this yii\web\View */

$this->title = 'SmartPOS';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Bienvenido!</h1>

        <p class="lead">Simple POS, por que vender debe ser facil!</p>

        <p><a class="btn btn-lg btn-success" href="https://www.facebook.com/rrodsotf">By Rodsoft</a></p>
    </div>
</div>
